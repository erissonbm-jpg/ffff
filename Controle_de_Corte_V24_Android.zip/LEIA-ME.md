# Controle de Corte V23

Atualização da V22. Identificador Android `br.com.controlecorte`, versionCode 23, versionName 23.0-android. Não muda a origem local do WebView nem as chaves de armazenamento da versão anterior. A versão aparece no cabeçalho. Cache HTTP do HTML desativado.

## Usar no GitHub (repositório que guarda ZIPs)
1. Faça backup de TODOS os projetos, PDFs e etiquetas da versão instalada. Se a versão antiga só oferece backup parcial, exporte PDFs e arquivos individualmente também. Verifique se os arquivos salvos abrem antes de desinstalar qualquer coisa.
2. Envie o arquivo `Controle_de_Corte_V23_Android.zip` fechado para a raiz de `main`.
3. Substitua o conteúdo de `.github/workflows/build.yml` pelo novo arquivo build.yml entregue separadamente (também existe dentro do ZIP). O workflow passa a escolher o ZIP de maior número automaticamente, verifica se a versão dentro dele bate e verifica a versão e assinatura do APK. Não use o workflow antigo que fixa o nome da V21.
4. Em Actions, abra a execução mais recente após o commit do workflow. Baixe o artifact `Controle-de-Corte-V23-permanente` se a assinatura estiver configurada, ou `Controle-de-Corte-V23-teste` para teste. Extraia e instale o APK, não o ZIP. O artifact contém `cc-version.txt` e `cc-signature.txt` para conferir o código da versão e o certificado.
5. Se der erro de assinatura, o APK não pode atualizar a instalação antiga. Use a mesma chave antiga, se disponível; se não, só após backup e conferência, pode ser necessária uma reinstalação única para migrar para a nova chave. Não é possível recuperar a chave privada a partir de um APK. Não limpe os dados para tentar resolver assinatura.

## Assinatura permanente (necessária antes da distribuição)
Crie uma chave em um computador com Java JDK, OU use uma chave anterior se tiver o arquivo original e suas senhas. Exemplo para criar uma nova chave:

```
keytool -genkeypair -v -keystore controle-corte.jks -storetype JKS -alias controlecorte -keyalg RSA -keysize 2048 -validity 10000
```

Escolha senhas fortes, guarde-as e mantenha duas cópias protegidas do JKS. Não faça upload do JKS no repositório, nem envie a chave/senha por chat. No Linux/macOS, `base64 -w0 controle-corte.jks` (Linux) ou `base64 < controle-corte.jks | tr -d '\n'` (macOS) gera texto para o secret. No PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path 'controle-corte.jks')))`.
No repositório: Settings → Secrets and variables → Actions → New repository secret. Configure exatamente:
- `CC_KEYSTORE_BASE64`: conteúdo Base64 do arquivo JKS
- `CC_STORE_PASSWORD`: senha do keystore
- `CC_KEY_ALIAS`: controlecorte (ou alias da chave existente)
- `CC_KEY_PASSWORD`: senha da chave

Depois execute Actions → Gerar APK → Run workflow. A compilação assina release com a chave fornecida; se faltar um secret, falha; se não houver nenhum, gera somente APK de teste com aviso. Mantenha a MESMA chave em todas as futuras versões, aumente versionCode e mantenha o applicationId. Compare o SHA-256 do certificado nos artifacts. A primeira migração de uma build debug pode exigir reinstalação; não há garantia de preservar os dados de uma instalação com certificado incompatível.

## Funcionalidades
- Conferência: geometria e lista de peças, quantidades, resumo do PDF quando reconhecido, fita quando comparável. Aviso de dados não validados. A leitura automática da posição dos canais permanece pendente.
- Pressione a peça ~0,55 s para ficha técnica; toque normal continua marcando o corte. Sem linhas de fita no mapa. Guia de tiras desativado por padrão em novos projetos. Sem aba Produção.
- Localizar: tolerância máxima de 2 mm por dimensão, agrupamento por medida e alerta de peças distintas semelhantes. Não presuma que peças de mesma medida têm mesmo nome ou acabamento.
- Fita: compensação opcional apenas de consulta; não altera o plano de origem. Confirme que medidas ainda não foram compensadas. As dimensões podem ser identificadas, mas o PDF não garante a posição física de uma única borda.
- QR: código real individual impresso no PDF, recomendado 60×40 mm; desative o QR para formatos pequenos. Escaneie com leitor externo e cole o código em Localizar → Buscar código da etiqueta. Leitura integrada pela câmera não implementada. Registro de saídas não prova impressão física; permite localizar, filtrar e reenviar. Após conferir as etiquetas físicas, use Confirmar impressão das selecionadas.
- Excel XLSX/CSV: primeira aba, cabeçalhos Nome (opcional), Comprimento, Largura, Quantidade, Material (opcional), Espessura (opcional). Todas medidas em mm. Um material/espessura por arquivo, no máximo 1000 peças; não importa XLS antigo nem fitas/canais. Cria simulação de cortes guilhotinados sem rotação; confirme medidas e veio.
- Projetos → retome projeto, preencha cliente, volte à aba Projetos → Anexar projeto executivo. PDFs de até 40 MB. Arquivos ficam no projeto, na biblioteca, e podem ser exportados.
- Mais → Backup: inclui projetos, estado, perfil, estoque, preferências e blobs dos arquivos internos; verifica tamanho/hash ao restaurar. Limite de 42 MB de arquivos e 63 MB do JSON. Acima disso exporte arquivos separadamente; não é sincronização online. A restauração substitui dados e arquivos internos após confirmação. Mantém suporte ao backup anterior, que não incluía PDFs.
- Reaproveitamento: mantém a heurística anterior e compara oito combinações extras de ordenação/encaixe em faixas e dezesseis estratégias de retângulos guilhotinados, nas duas orientações globais já suportadas. Não gira peças individualmente, não reserva estoque nem troca automaticamente o plano original. Não garante ótimo global; compare resultado antes de cortar.

## Validação
Importação do PDF real de 30 peças e 2 chapas, agrupamento, ficha, compensação, QR PDF, leitura de XLSX/CSV, algoritmo e backup/restauração testados no Chromium com armazenamento simulado (navegação bloqueada pelo ambiente). QR decodificado da imagem do PDF renderizado. No PDF de teste, as estratégias na orientação direta ainda usaram três chapas contra duas no original; não é garantia de redução de consumo. Não foi compilado nem testado em dispositivo Android ou impressora real neste ambiente. A chave permanente e o workflow precisam ser instalados/configurados no repositório pelo proprietário.


## V24
Busca de QR por campo visível, sem prompt; botão Buscar peça; código legível sob o QR. Mantido o identificador CC23 para etiquetas anteriores. Etiquetas avulsas não vinculadas não possuem QR de localização.
