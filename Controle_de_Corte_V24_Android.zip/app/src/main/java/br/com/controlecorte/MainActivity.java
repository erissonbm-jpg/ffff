package br.com.controlecorte;

import android.app.Activity;
import android.bluetooth.*;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.pdf.PdfRenderer;
import android.os.Build;
import android.content.pm.PackageManager;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.*;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.util.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String HOME = "https://controle.local/index.html";
    private static final int PICK=10, SAVE=11, MAX=64*1024*1024;
    private WebView web;
    private boolean ready=false;
    private Uri queued;
    private ValueCallback<Uri[]> picker;
    private volatile String sharedPath;
    private volatile byte[] sharedBytes;
    private File savingFile;
    private OutputStream savingStream;
    private String savingName, savingMime;
    private int written, expected;
    private boolean choosingSave;
    private int shareGeneration;
    private final AtomicBoolean thermalBusy=new AtomicBoolean(false);
    private static final int BT_PERMISSION=22;
    private boolean btAllowed(){return Build.VERSION.SDK_INT<31||checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
    private BluetoothAdapter adapter(){BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);return bm==null?null:bm.getAdapter();}
    private void chooseThermal(){
        if(!btAllowed()){requestPermissions(new String[]{android.Manifest.permission.BLUETOOTH_CONNECT},BT_PERMISSION);return;}
        try{BluetoothAdapter a=adapter();if(a==null||!a.isEnabled()){message("Ative o Bluetooth e pareie a impressora.");return;}
            ArrayList<BluetoothDevice> devices=new ArrayList<>(a.getBondedDevices());
            if(devices.isEmpty()){message("Nenhuma impressora pareada. Abra as configurações de Bluetooth.");return;}
            String[] labels=new String[devices.size()];for(int i=0;i<devices.size();i++){BluetoothDevice d=devices.get(i);labels[i]=(d.getName()==null?"Dispositivo":d.getName())+" — "+d.getAddress();}
            new AlertDialog.Builder(this).setTitle("Selecione a impressora TSPL pareada").setItems(labels,(dialog,i)->{getPreferences(MODE_PRIVATE).edit().putString("thermalAddress",devices.get(i).getAddress()).apply();message("Impressora selecionada. Faça um teste de uma etiqueta.");}).setNegativeButton("Cancelar",null).show();
        }catch(Exception e){message("Não foi possível listar dispositivos pareados.");}
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){super.onRequestPermissionsResult(code,permissions,results);if(code==BT_PERMISSION&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)chooseThermal();}
    private void ascii(OutputStream out,String text) throws IOException {out.write(text.getBytes(StandardCharsets.US_ASCII));}
    private void thermalSend(File file,String address,double width,double height,int pages,int dpi,double gap){
        int sent=0;try{BluetoothAdapter a=adapter();if(a==null||!a.isEnabled())throw new IOException("Bluetooth desligado");BluetoothDevice d=a.getRemoteDevice(address);if(d.getBondState()!=BluetoothDevice.BOND_BONDED)throw new IOException("Impressora não pareada");
            try(BluetoothSocket socket=d.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));PdfRenderer renderer=new PdfRenderer(ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY))){
                if(renderer.getPageCount()!=pages)throw new IOException("Número de etiquetas inconsistente");
                // Close the socket if connection stalls. No automatic retry, to avoid duplicate labels.
                android.os.Handler timer=new android.os.Handler(android.os.Looper.getMainLooper());Runnable timeout=()->{try{socket.close();}catch(Exception ignored){}};timer.postDelayed(timeout,15000);try{socket.connect();}finally{timer.removeCallbacks(timeout);}
                OutputStream out=socket.getOutputStream();int w=(int)Math.floor(width/25.4*dpi),h=(int)Math.floor(height/25.4*dpi),stride=(w+7)/8;
                for(int i=0;i<pages;i++){try(PdfRenderer.Page page=renderer.openPage(i)){Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);try{bmp.eraseColor(Color.WHITE);page.render(bmp,new Rect(0,0,w,h),null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);byte[] raster=new byte[stride*h];Arrays.fill(raster,(byte)0xff);int[] row=new int[w];for(int y=0;y<h;y++){bmp.getPixels(row,0,w,0,y,w,1);for(int x=0;x<w;x++){int c=row[x];if(Color.red(c)*299+Color.green(c)*587+Color.blue(c)*114<150000)raster[y*stride+x/8]&=(byte)~(128>>(x%8));}}
                    ascii(out,String.format(Locale.US,"SIZE %.2f mm,%.2f mm\r\nGAP %.2f mm,0 mm\r\nDIRECTION 1\r\nCLS\r\nBITMAP 0,0,%d,%d,0,",width,height,gap,stride,h));out.write(raster);ascii(out,"\r\nPRINT 1,1\r\n");out.flush();sent++;Thread.sleep(200);
                    }finally{bmp.recycle();}}}
            }
            final int n=sent;runOnUiThread(()->message(n+" etiqueta(s) enviada(s). Confira a impressão física."));
        }catch(Exception e){final int n=sent;runOnUiThread(()->message("Envio interrompido após "+n+" etiqueta(s). Confira antes de reenviar: "+e.getMessage()));}finally{file.delete();thermalBusy.set(false);}
    }


    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff203631); getWindow().setNavigationBarColor(0xff203631);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(),"AndroidBridge");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return !HOME.equals(r.getUrl().toString());}
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url){return !HOME.equals(url);}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
                String url=r.getUrl().toString();
                try {
                    if(HOME.equals(url)) return new WebResourceResponse("text/html","UTF-8",200,"OK",Collections.singletonMap("Cache-Control","no-store"),getAssets().open("index.html"));
                    byte[] b=sharedBytes; String path=sharedPath;
                    if(b!=null && path!=null && url.equals("https://controle.local/"+path)){
                        Map<String,String> headers=new HashMap<>();headers.put("Cache-Control","no-store");
                        return new WebResourceResponse("application/pdf",null,200,"OK",headers,new ByteArrayInputStream(b));
                    }
                } catch(IOException ignored){}
                return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
            }
            @Override public void onPageFinished(WebView v,String url){if(HOME.equals(url)){ready=true; if(queued!=null){Uri u=queued;queued=null;offerImport(u);}}}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){
                if(picker!=null)picker.onReceiveValue(null);picker=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","application/json","application/octet-stream","text/csv","text/comma-separated-values","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
                try{startActivityForResult(i,PICK);}catch(Exception e){picker.onReceiveValue(null);picker=null;message("Não foi possível abrir o seletor de arquivos.");}return true;
            }
        });
        queued=extract(getIntent());web.loadUrl(HOME);
    }
    private Uri extract(Intent i){
        if(i==null)return null;String action=i.getAction();
        if(Intent.ACTION_VIEW.equals(action))return i.getData();
        if(Intent.ACTION_SEND.equals(action)){
            Object x=i.getParcelableExtra(Intent.EXTRA_STREAM);if(x instanceof Uri)return (Uri)x;
            if(i.getClipData()!=null && i.getClipData().getItemCount()>0)return i.getClipData().getItemAt(0).getUri();
        }return null;
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);Uri u=extract(i);if(u!=null){if(ready)offerImport(u);else queued=u;}}
    private void offerImport(Uri u){
        if(!"content".equals(u.getScheme()) && !"file".equals(u.getScheme())){message("Arquivo incompatível.");return;}
        int generation=++shareGeneration;
        new Thread(()->{
            try(InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                if(in==null)throw new IOException("Arquivo inacessível");byte[] buffer=new byte[32768];int n;
                while((n=in.read(buffer))!=-1){if(out.size()+n>MAX)throw new IOException("PDF maior que 64 MB");out.write(buffer,0,n);}
                byte[] data=out.toByteArray();if(data.length<5||data[0]!='%'||data[1]!='P'||data[2]!='D'||data[3]!='F'||data[4]!='-')throw new IOException("O arquivo compartilhado não é um PDF.");
                String name="Plano de corte.pdf";try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst()&&!c.isNull(0))name=c.getString(0);}catch(Exception ignored){}
                String filename=name, path="import/"+UUID.randomUUID();
                runOnUiThread(()->{if(generation!=shareGeneration||isFinishing())return;sharedBytes=data;sharedPath=path;web.evaluateJavascript("window.importAndroidPDF("+JSONObject.quote(path)+","+JSONObject.quote(filename)+")",null);});
            }catch(Exception e){runOnUiThread(()->message("Não foi possível importar: "+e.getMessage()));}
        }).start();
    }
    private void message(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    private synchronized void clearSave(){try{if(savingStream!=null)savingStream.close();}catch(IOException ignored){}savingStream=null;if(savingFile!=null)savingFile.delete();savingFile=null;choosingSave=false;}
    private class Bridge {
        @JavascriptInterface public void pickThermal(){runOnUiThread(()->chooseThermal());}
        @JavascriptInterface public boolean finishThermal(double width,double height,int pages,int dpi,double gap){
            synchronized(MainActivity.this){String address=getPreferences(MODE_PRIVATE).getString("thermalAddress","");if(!btAllowed()||address.isEmpty()||savingStream==null||written!=expected||!"application/pdf".equals(savingMime)||!Double.isFinite(width)||!Double.isFinite(height)||!Double.isFinite(gap)||width<35||width>110||height<25||height>100||gap<0||gap>10||(dpi!=203&&dpi!=300)||pages<1||pages>100||!thermalBusy.compareAndSet(false,true))return false;
                try{savingStream.close();savingStream=null;File file=savingFile;savingFile=null;new Thread(()->thermalSend(file,address,width,height,pages,dpi,gap)).start();return true;}catch(Exception e){thermalBusy.set(false);clearSave();return false;}}
        }

        @JavascriptInterface public void keepScreenOn(boolean on){runOnUiThread(()->{if(on)getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);});}
        @JavascriptInterface public synchronized boolean beginSave(String name,String mime,int length){
            synchronized(MainActivity.this){if(choosingSave||length<=0||length>MAX||!("application/pdf".equals(mime)||"application/json".equals(mime)||"text/csv".equals(mime)||"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".equals(mime)||"application/octet-stream".equals(mime)||"text/plain".equals(mime)))return false;
                clearSave();try{savingFile=File.createTempFile("controle-",".tmp",getCacheDir());savingStream=new FileOutputStream(savingFile);savingName=name.replaceAll("[\\\\/:*?\"<>|]","-");savingMime=mime;written=0;expected=length;return true;}catch(Exception e){clearSave();return false;}}
        }
        @JavascriptInterface public boolean appendSave(String chunk){synchronized(MainActivity.this){try{if(savingStream==null||chunk.length()>200000)return false;byte[] b=Base64.decode(chunk,Base64.DEFAULT);if(written+b.length>expected)throw new IOException();savingStream.write(b);written+=b.length;return true;}catch(Exception e){clearSave();return false;}}}
        @JavascriptInterface public boolean finishSave(){synchronized(MainActivity.this){try{if(savingStream==null||written!=expected)throw new IOException();savingStream.close();savingStream=null;choosingSave=true;runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(savingMime);i.putExtra(Intent.EXTRA_TITLE,savingName);startActivityForResult(i,SAVE);}catch(Exception e){clearSave();message("Não foi possível abrir a janela de salvamento.");}});return true;}catch(Exception e){clearSave();return false;}}}
        @JavascriptInterface public boolean finishPrint(double width, double height, int pages){
            synchronized(MainActivity.this){
                if(savingStream==null||written!=expected||!"application/pdf".equals(savingMime)||width<35||width>110||height<25||height>100||pages<1||pages>1000)return false;
                try{savingStream.close();savingStream=null;File file=savingFile;savingFile=null;
                    runOnUiThread(()->{try{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                        PrintAttributes.MediaSize media=new PrintAttributes.MediaSize("LABEL_"+width+"x"+height,"Etiqueta "+width+" x "+height+" mm",(int)Math.round(width/25.4*1000),(int)Math.round(height/25.4*1000));
                        PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(media).setMinMargins(PrintAttributes.Margins.NO_MARGINS).setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME).build();
                        pm.print("Etiquetas Controle de Corte",new PrintDocumentAdapter(){
                            @Override public void onLayout(PrintAttributes oldAttrs,PrintAttributes newAttrs,CancellationSignal cancel,LayoutResultCallback cb,Bundle extras){
                                if(cancel.isCanceled()){cb.onLayoutCancelled();return;}
                                cb.onLayoutFinished(new PrintDocumentInfo.Builder("Etiquetas.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(pages).build(),!newAttrs.equals(oldAttrs));
                            }
                            @Override public void onWrite(PageRange[] ranges,ParcelFileDescriptor dest,CancellationSignal cancel,WriteResultCallback cb){
                                new Thread(()->{try(InputStream in=new FileInputStream(file);OutputStream out=new ParcelFileDescriptor.AutoCloseOutputStream(dest)){
                                    byte[] buf=new byte[32768];int n;while((n=in.read(buf))!=-1){if(cancel.isCanceled()){cb.onWriteCancelled();return;}out.write(buf,0,n);}out.flush();if(cancel.isCanceled())cb.onWriteCancelled();else cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                                }catch(Exception e){if(cancel.isCanceled())cb.onWriteCancelled();else cb.onWriteFailed("Não foi possível preparar o PDF.");}}).start();
                            }
                            @Override public void onFinish(){file.delete();}
                        },attrs);
                    }catch(Exception e){file.delete();message("Serviço de impressão indisponível. Salve o PDF para imprimir.");}});return true;
                }catch(Exception e){clearSave();return false;}
            }
        }
        @JavascriptInterface public void abortSave(){synchronized(MainActivity.this){if(!choosingSave)clearSave();}}
        @JavascriptInterface public void releaseImport(String path){if(path.equals(sharedPath)){sharedBytes=null;sharedPath=null;}}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==PICK&&picker!=null){picker.onReceiveValue(result==RESULT_OK?WebChromeClient.FileChooserParams.parseResult(result,data):null);picker=null;}
        if(request==SAVE){if(result!=RESULT_OK||data==null||data.getData()==null){clearSave();message("Salvamento cancelado.");return;}
            Uri uri=data.getData();File temp=savingFile;new Thread(()->{try(InputStream in=new FileInputStream(temp);OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new IOException();byte[] buf=new byte[32768];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();runOnUiThread(()->message("Arquivo salvo."));}catch(Exception e){runOnUiThread(()->message("Falha ao salvar. Tente novamente."));}finally{clearSave();}}).start();}
    }
    @Override public void onBackPressed(){web.evaluateJavascript("typeof window.appBack === 'function' ? window.appBack() : false",r->{if(!"true".equals(r))new AlertDialog.Builder(this).setMessage("Sair do Controle de Corte?").setNegativeButton("Continuar",null).setPositiveButton("Sair",(d,w)->finish()).show();});}
}
