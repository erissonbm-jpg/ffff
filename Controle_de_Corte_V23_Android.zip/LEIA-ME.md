# Controle de Corte V23 — Android

Projeto fonte para compilar o APK (não é APK pronto). Mantém a identificação br.com.controlecorte, origem WebView e chaves anteriores. Atualize com a mesma chave de assinatura; preserve os backups externos e os PDFs antes de atualizar.

## Ajuste V23
- Corrigida a marcação por toque simples: a ação é chamada diretamente após o toque, sem depender de clique simulado. Gestos de dois dedos e arrastes não marcam peças.
- Teste Chromium móvel com dois itens simulados: marcar/desmarcar, zoom 340%, marcação ampliada, arraste, ajuste, gravação de estado. Não testado no Android físico.

## Ajuste V22

- Zoom na chapa de 100% a 600% com dois dedos ou botões + e −.
- Arraste para navegar quando ampliado; Ajustar restaura a chapa inteira.
- Gestos não marcam peças; toque simples continua funcionando.
- O zoom visual não é incluído nos PDFs exportados.
- Antes de atualizar, exporte o backup de dados e os PDFs. A atualização sobre a instalação anterior exige a mesma chave de assinatura Android.

## Ajuste V21
- Removidas as linhas e siglas de fita de todas as chapas, inclusive no PDF exportado. Etiquetas mantêm o tipo e dimensão e exibem amostras de linha contínua/tracejada em preto, sem inferir lado físico. Aba Fita e conferência por peça preservadas. Canais e sobras inalterados.

## Alterações anteriores
- Removida a aba Produção. Navegação: Projetos, Corte, Etiquetas, Fita, Mais.
- Dentro do plano de corte: Corte, Fitar, Canal e Guia. Conferência de fitas por peça e por dimensão, sem marcação gráfica de fita no mapa. Atribuição manual do lado após conferência da face. Mantém folga por ponta e metragem validada.
- Canais para fundo: leitura do total informado e dos parâmetros quando reconhecidos. Cadastro manual de lado, recuo a partir da borda até o início do canal, largura e profundidade. Opção de replicar para peças do mesmo ID e orientação, sem canal cadastrado. Marcações e medidas salvas, incluídas em etiquetas e relatórios de corte e restauradas ao reabrir o PDF. O PDF de teste contém zero sulcos; a localização automática de canais não está implementada. Confirme a face e o desenho antes de usinar.
- Guia: indica separações geométricas sem cruzar peças, a partir das tiras reconhecidas. Posição do corredor em relação à origem do mapa, não ajuste de máquina. Não é uma sequência completa validada para uma esquadrejadeira; confirmação do guia não marca as peças como cortadas. Confira disco, refilo e apoio físico.
- Refazer peça: registra motivo, volta ao corte e limpa marcas de fitagem e canal concluído. A geometria original permanece intacta. Use simulação de retalhos para reposição.
- Simulação de plano: heurística de faixas horizontais ou verticais, comprimento da peça fixo em relação ao comprimento da chapa. Considera kerf/refilo, dimensões reais e material/espessura do retalho. Pode colocar várias peças em um retalho. Não é ótimo global, não altera plano original, não reserva estoque, não permite girar peças individualmente. Só compare economia se não houve cortes e não há sobras no plano original. A simulação pode gastar mais chapas que o SketchCut; nesse caso mantenha o plano original. Confira o veio e as dimensões antes de cortar. PDF de simulação lista coordenadas e medidas; mapa visual no aplicativo.
- Lista de compras: consolida chapas novas e fita com folga do projeto aberto ou projetos guardados do mesmo cliente. Preços unitários informados manualmente, subtotal parcial quando faltarem preços. Não deduz estoque automaticamente; não calcula ferragens. Fita sem validação não é contabilizada. Confirme a largura comercial e cor da fita antes de comprar.
- Etiquetas: PDF, impressão Android, Bluetooth clássico SPP para impressoras compatíveis com TSPL (203/300 dpi e intervalo configurável). Pareie no Android, escolha a impressora na aba Etiquetas, envie uma etiqueta de teste e confira tamanho, orientação e saída. Envio automático ao marcar corte é opt-in de sessão; não há confirmação física, fila de reenvio ou garantia de entrega. Evite marcar novo corte antes de concluir o envio anterior. Wi-Fi/USB diretos, BLE, ZPL, ESC/POS e outros protocolos não implementados. O serviço Android continua disponível conforme compatibilidade do fabricante.
- Arquivos, clientes, ambientes, relatórios e perfil continuam locais; backup JSON não inclui PDFs internos. Exporte-os separadamente. Não há autenticação remota ou pagamentos.

## Testes da V22
Chromium em viewport móvel com eventos de toque de dois dedos simulados: zoom 225%, deslocamento, toque simples sem duplicação, botões, ajuste à chapa inteira e preservação do zoom ao redesenhar o mapa de teste. Sem erros JavaScript no fluxo testado. Não executado no Android.

## Testes históricos da V21
Executado Chromium com armazenamento local simulado, sem erros JavaScript nos fluxos testados. PDF real teste 1.pdf: 30 peças, 2 chapas, 35 bordas; 12,640 m tipo 1, 26,448 m tipo 2; 40,488 m com 20 mm por ponta. Total de sulcos 0, configuração lida 15/4/8 mm. Testadas marcação de borda, cadastro e marcação de canal manual, simulação das peças pendentes (encaixe de todas, 3 chapas novas no cenário sem retalhos), lista de compras, geração e reimportação de relatório com canal preservado. A simulação não melhorou o plano original no exemplo e não deve substituí-lo. Navegação real do arquivo local foi bloqueada no ambiente; teste executado com conteúdo HTML carregado em memória. Não compilado em Android; armazenamento real, Bluetooth, APK, compartilhamento e impressão física precisam de teste.

## Gerar APK
1. Guarde backups JSON e PDFs fora do app, e a chave original de assinatura.
2. Extraia o ZIP e substitua o conteúdo do projeto existente no GitHub, incluindo app/ e .github/workflows/build.yml. Não envie PDFs de clientes ao repositório.
3. Actions > Gerar APK. Aguarde o workflow terminar; baixe o artefato Controle-de-Corte-APK e extraia app-debug.apk.
4. Instale como atualização apenas se a assinatura coincidir. Executores novos do GitHub podem gerar chaves debug diferentes. Se o Android acusar incompatibilidade, NÃO desinstale sem backup e sem confirmar como restaurar. Para distribuição comercial use chave release persistente.
5. Android Studio local: JDK 17, SDK 34, Gradle 8.7, AGP 8.5.2. Execute gradle :app:assembleDebug.


## V19 - Ajuste visual
Sobras em cinza claro hachurado, contorno discreto e fita tipo 2 em azul acinzentado tracejado. Sem alteracoes nas medidas, identificadores, armazenamento ou geometria.
