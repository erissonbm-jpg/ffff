# Controle de Corte — Android (projeto-fonte)

**Não é um APK compilado.** O código precisa ser compilado e testado em Android. A versão usa a interface V12 em uma WebView local, sem acesso à internet. O Android registra o app como receptor de PDFs em Compartilhar e Abrir com. O seletor nativo permite importar e salvar PDFs e backups.

## Compilar no computador
1. Instale Android Studio, SDK Android 34, Build Tools 34 e JDK 17.
2. Extraia este ZIP e abra a pasta no Android Studio. Sincronize o Gradle (8.7, AGP 8.5.2).
3. Escolha Build > Build Bundle(s)/APK(s) > Build APK(s) (o nome do menu pode variar). O APK de teste fica em app/build/outputs/apk/debug/app-debug.apk. Alternativamente: `gradle :app:assembleDebug` com Gradle 8.7.

## Compilar pelo GitHub (sem Android Studio)
Crie um repositório privado e envie o conteúdo da pasta, incluindo a pasta oculta .github. Em Actions > Gerar APK > Run workflow, execute a compilação e baixe o artefato Controle-de-Corte-APK. O ZIP do artefato contém app-debug.apk. Não envie PDFs de clientes ao repositório. A compilação depende da disponibilidade das dependências e do SDK no executor.

## Testar
Instale o APK de teste em um dispositivo Android (Android 6+; previsto para Android 14). Autorize a instalação da fonte escolhida somente se confiar no arquivo. Abra um PDF de teste no SketchCut e escolha Compartilhar > Controle de Corte. Confirme nomes, cotas, sobras e quantidades antes de cortar. Marque peças e tiras, salve o PDF em uma pasta e reabra o mesmo PDF. Confirme a restauração e o vermelho dos itens pendentes. Teste também abrir o app, importar manualmente e compartilhar um segundo PDF.

O leitor continua restrito aos PDFs compatíveis do SketchCut e aos relatórios com retomada. Nenhuma permissão de internet é solicitada. A compilação e a execução nativa não puderam ser verificadas neste ambiente. O aplicativo de teste utiliza assinatura de depuração; para distribuição definitiva, gere uma chave de release própria e preserve-a.
