package br.com.controlecorte;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.util.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String HOME = "https://controle.local/index.html";
    private static final int PICK=10, SAVE=11, MAX=64*1024*1024;
    private WebView web;
    private boolean ready=false;
    private Uri queued;
    private ValueCallback<Uri[]> picker;
    private volatile String sharedPath;
    private volatile byte[] sharedBytes;
    private File savingFile;
    private OutputStream savingStream;
    private String savingName, savingMime;
    private int written, expected;
    private boolean choosingSave;
    private int shareGeneration;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(),"AndroidBridge");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return !HOME.equals(r.getUrl().toString());}
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url){return !HOME.equals(url);}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
                String url=r.getUrl().toString();
                try {
                    if(HOME.equals(url)) return new WebResourceResponse("text/html","UTF-8",getAssets().open("index.html"));
                    byte[] b=sharedBytes; String path=sharedPath;
                    if(b!=null && path!=null && url.equals("https://controle.local/"+path)){
                        Map<String,String> headers=new HashMap<>();headers.put("Cache-Control","no-store");
                        return new WebResourceResponse("application/pdf",null,200,"OK",headers,new ByteArrayInputStream(b));
                    }
                } catch(IOException ignored){}
                return new WebResourceResponse("text/plain","UTF-8",403,"Forbidden",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
            }
            @Override public void onPageFinished(WebView v,String url){if(HOME.equals(url)){ready=true; if(queued!=null){Uri u=queued;queued=null;offerImport(u);}}}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){
                if(picker!=null)picker.onReceiveValue(null);picker=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","application/json","application/octet-stream"});
                try{startActivityForResult(i,PICK);}catch(Exception e){picker.onReceiveValue(null);picker=null;message("Não foi possível abrir o seletor de arquivos.");}return true;
            }
        });
        queued=extract(getIntent());web.loadUrl(HOME);
    }
    private Uri extract(Intent i){
        if(i==null)return null;String action=i.getAction();
        if(Intent.ACTION_VIEW.equals(action))return i.getData();
        if(Intent.ACTION_SEND.equals(action)){
            Object x=i.getParcelableExtra(Intent.EXTRA_STREAM);if(x instanceof Uri)return (Uri)x;
            if(i.getClipData()!=null && i.getClipData().getItemCount()>0)return i.getClipData().getItemAt(0).getUri();
        }return null;
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);Uri u=extract(i);if(u!=null){if(ready)offerImport(u);else queued=u;}}
    private void offerImport(Uri u){
        if(!"content".equals(u.getScheme()) && !"file".equals(u.getScheme())){message("Arquivo incompatível.");return;}
        int generation=++shareGeneration;
        new Thread(()->{
            try(InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                if(in==null)throw new IOException("Arquivo inacessível");byte[] buffer=new byte[32768];int n;
                while((n=in.read(buffer))!=-1){if(out.size()+n>MAX)throw new IOException("PDF maior que 64 MB");out.write(buffer,0,n);}
                byte[] data=out.toByteArray();if(data.length<5||data[0]!='%'||data[1]!='P'||data[2]!='D'||data[3]!='F'||data[4]!='-')throw new IOException("O arquivo compartilhado não é um PDF.");
                String name="Plano de corte.pdf";try(Cursor c=getContentResolver().query(u,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst()&&!c.isNull(0))name=c.getString(0);}catch(Exception ignored){}
                String filename=name, path="import/"+UUID.randomUUID();
                runOnUiThread(()->{if(generation!=shareGeneration||isFinishing())return;sharedBytes=data;sharedPath=path;web.evaluateJavascript("window.importAndroidPDF("+JSONObject.quote(path)+","+JSONObject.quote(filename)+")",null);});
            }catch(Exception e){runOnUiThread(()->message("Não foi possível importar: "+e.getMessage()));}
        }).start();
    }
    private void message(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    private synchronized void clearSave(){try{if(savingStream!=null)savingStream.close();}catch(IOException ignored){}savingStream=null;if(savingFile!=null)savingFile.delete();savingFile=null;choosingSave=false;}
    private class Bridge {
        @JavascriptInterface public synchronized boolean beginSave(String name,String mime,int length){
            synchronized(MainActivity.this){if(choosingSave||length<=0||length>MAX||!("application/pdf".equals(mime)||"application/json".equals(mime)))return false;
                clearSave();try{savingFile=File.createTempFile("controle-",".tmp",getCacheDir());savingStream=new FileOutputStream(savingFile);savingName=name.replaceAll("[\\\\/:*?\"<>|]","-");savingMime=mime;written=0;expected=length;return true;}catch(Exception e){clearSave();return false;}}
        }
        @JavascriptInterface public boolean appendSave(String chunk){synchronized(MainActivity.this){try{if(savingStream==null||chunk.length()>200000)return false;byte[] b=Base64.decode(chunk,Base64.DEFAULT);if(written+b.length>expected)throw new IOException();savingStream.write(b);written+=b.length;return true;}catch(Exception e){clearSave();return false;}}}
        @JavascriptInterface public boolean finishSave(){synchronized(MainActivity.this){try{if(savingStream==null||written!=expected)throw new IOException();savingStream.close();savingStream=null;choosingSave=true;runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(savingMime);i.putExtra(Intent.EXTRA_TITLE,savingName);startActivityForResult(i,SAVE);}catch(Exception e){clearSave();message("Não foi possível abrir a janela de salvamento.");}});return true;}catch(Exception e){clearSave();return false;}}}
        @JavascriptInterface public void abortSave(){synchronized(MainActivity.this){if(!choosingSave)clearSave();}}
        @JavascriptInterface public void releaseImport(String path){if(path.equals(sharedPath)){sharedBytes=null;sharedPath=null;}}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==PICK&&picker!=null){picker.onReceiveValue(result==RESULT_OK?WebChromeClient.FileChooserParams.parseResult(result,data):null);picker=null;}
        if(request==SAVE){if(result!=RESULT_OK||data==null||data.getData()==null){clearSave();message("Salvamento cancelado.");return;}
            Uri uri=data.getData();File temp=savingFile;new Thread(()->{try(InputStream in=new FileInputStream(temp);OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new IOException();byte[] buf=new byte[32768];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();runOnUiThread(()->message("Arquivo salvo."));}catch(Exception e){runOnUiThread(()->message("Falha ao salvar. Tente novamente."));}finally{clearSave();}}).start();}
    }
    @Override public void onBackPressed(){web.evaluateJavascript("typeof detailIndex !== 'undefined' && detailIndex >= 0 ? (closeDetail(),true) : false",r->{if(!"true".equals(r))new AlertDialog.Builder(this).setMessage("Sair do Controle de Corte?").setNegativeButton("Continuar",null).setPositiveButton("Sair",(d,w)->finish()).show();});}
}
